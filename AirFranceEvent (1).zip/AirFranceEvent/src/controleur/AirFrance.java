package controleur;

import modele.Modele;
import vue.VueConnexion;
import vue.VueGenerale;

public class AirFrance {
	private static VueConnexion uneConnexion;
	private static VueGenerale uneVueGenerale;
	
	public static void rendreVisibleVueConnexion (boolean action) {
		uneConnexion.setVisible(action);
	}
	public static void rendreVisibleVueGenerale (boolean action) {
		uneVueGenerale.setVisible(action);
	}
	public static void instancierVueGenerale(User unUser) {
		uneVueGenerale = new VueGenerale(unUser);
	}
	public static void fermerVueGenerale( ) {
		uneVueGenerale.dispose();
	}
	
	public static void main(String[] args) {
		uneConnexion = new VueConnexion();
	}
	/*************Gestion des users*******************/
	public static User selectWhereUser (String email, String mdp) {
		//
		//
		User unUser = Modele.selectWhereUser(email, mdp);
		
		return unUser;
	}

}
