package vue;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import controleur.AirFrance;
import controleur.User;

public class VueGenerale extends JFrame implements ActionListener {
    
    private JButton btQuitter = new JButton("D�connexion");
    private JButton btProfil = new JButton("Mon Profil");
    private JButton btPilotes = new JButton("Pilotes");
    private JButton btAvions = new JButton("Avions");
    private JButton btVols = new JButton("Vols");
    private JButton btStats = new JButton("Statistiques");
    private JButton btBoard = new JButton("Tableau de bord");
    /********* les panels*************/
    private JPanel panelMenu = new JPanel();
    private JPanel panelProfil = new JPanel();
	
    private static PanelPilote unPanelPilote= new PanelPilote();
    private static PanelAvion unPanelAvion= new PanelAvion();
    private static PanelVol unPanelVol= new PanelVol();
    
    public VueGenerale (User unUser) {
    	System.out.println(unUser.getNom());
        this.setTitle("Air France Administration");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.getContentPane().setBackground(Color.cyan);
        this.setBounds(300, 300, 900, 500);
        this.setLayout(null);
        
        // Construction du panel menu
        this.panelMenu.setLayout(new GridLayout(1, 7));
        this.panelMenu.setBounds(20, 10, 860, 40);
        this.panelMenu.setBackground(Color.cyan);
        this.panelMenu.add(btProfil);
        this.panelMenu.add(btPilotes);
        this.panelMenu.add(btAvions);
        this.panelMenu.add(btVols);
        this.panelMenu.add(btStats);
        this.panelMenu.add(btBoard);
        this.panelMenu.add(btQuitter);
        this.add(this.panelMenu);
        //insertion des panels d'administration: pilote / avion/ vol
        this.add(unPanelPilote);
        this.add(unPanelAvion);
        this.add(unPanelVol);
        
        // Construction du panel PROFIL
        this.panelProfil.setLayout(new GridLayout(4, 1));
        this.panelProfil.setBounds(250, 100, 400, 300);
        this.panelProfil.setBackground(Color.yellow);
        this.panelProfil.setVisible(false);
		this.panelProfil.add(new JLabel("Nom de l'user : "+unUser.getNom()));
		this.panelProfil.add(new JLabel("Prenom de l'user : "+unUser.getPrenom()));
		this.panelProfil.add(new JLabel("Email de l'user : "+unUser.getEmail()));
		this.panelProfil.add(new JLabel("Role de l'user : "+unUser.getRole()));

		
        this.add(this.panelProfil);
        
        
        //rendre les boutton cliquable
        this.btProfil.addActionListener(this);
        this.btPilotes.addActionListener(this);
        this.btAvions.addActionListener(this);
        this.btVols.addActionListener(this);
        this.btStats.addActionListener(this);
        this.btBoard.addActionListener(this);
        this.btQuitter.addActionListener(this);
        this.setVisible(true);
    }

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == this.btQuitter)
		{
			AirFrance.fermerVueGenerale();
			AirFrance.rendreVisibleVueConnexion(true);
		}
		else if(e.getSource()== this.btProfil) {
			this.panelProfil.setVisible(true);
			unPanelPilote.setVisible(false);
			unPanelAvion.setVisible(false);
			unPanelVol.setVisible(false);
			
		}
		else if(e.getSource()== this.btPilotes) {
			this.panelProfil.setVisible(false);
			unPanelPilote.setVisible(true);
			unPanelAvion.setVisible(false);
			unPanelVol.setVisible(false);
			
		}
		else if(e.getSource()== this.btAvions) {
			this.panelProfil.setVisible(false);
			unPanelPilote.setVisible(false);
			unPanelAvion.setVisible(true);
			unPanelVol.setVisible(false);
			
		}
		else if(e.getSource()== this.btVols) {
			this.panelProfil.setVisible(false);
			unPanelPilote.setVisible(false);
			unPanelAvion.setVisible(false);
			unPanelVol.setVisible(true);
			
		}
		
	}

}