package vue;

import java.awt.Color;

public class PanelAvion extends PanelDeBase{
	public PanelAvion() {
		super(Color.gray);
	}

}
