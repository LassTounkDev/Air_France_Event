package vue;

import java.awt.Color;

public class PanelVol extends PanelDeBase{
	public PanelVol() {
		super(Color.gray);
	}

}
